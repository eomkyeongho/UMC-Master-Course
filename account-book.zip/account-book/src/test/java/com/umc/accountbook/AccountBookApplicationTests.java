package com.umc.accountbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
